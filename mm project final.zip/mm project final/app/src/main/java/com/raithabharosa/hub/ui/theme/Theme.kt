package com.raithabharosa.hub.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = LeafGreen,
    onPrimary = OffWhite,
    primaryContainer = SoftGreen,
    onPrimaryContainer = DeepLeaf,
    secondary = SoilBrown,
    onSecondary = OffWhite,
    secondaryContainer = MilletGold,
    onSecondaryContainer = Bark,
    tertiary = MilletGold,
    onTertiary = Bark,
    background = Sand,
    onBackground = Bark,
    surface = OffWhite,
    onSurface = Bark,
    surfaceVariant = CloudMist,
    outline = SoilBrown,
)

private val DarkColors = darkColorScheme(
    primary = MilletGold,
    onPrimary = Bark,
    primaryContainer = DeepLeaf,
    onPrimaryContainer = OffWhite,
    secondary = SoftGreen,
    onSecondary = Bark,
    background = Bark,
    onBackground = OffWhite,
    surface = DeepLeaf,
    onSurface = OffWhite,
    surfaceVariant = LeafGreen,
    outline = MilletGold,
)

@Composable
fun RaithaBharosaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = RaithaTypography,
        content = content,
    )
}

