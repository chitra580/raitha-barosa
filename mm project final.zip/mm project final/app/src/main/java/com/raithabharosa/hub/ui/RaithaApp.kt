package com.raithabharosa.hub.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.raithabharosa.hub.R
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.ui.screen.ActionPlanRoute
import com.raithabharosa.hub.ui.screen.DashboardRoute
import com.raithabharosa.hub.ui.screen.HistoryRoute
import com.raithabharosa.hub.ui.screen.InputCenterRoute
import com.raithabharosa.hub.ui.screen.KrishiAiChatRoute
import com.raithabharosa.hub.ui.screen.OnboardingRoute

private data class MainDestination(
    val route: String,
    val labelRes: Int,
    val subtitleRes: Int,
    val icon: ImageVector,
)

private val mainDestinations = listOf(
    MainDestination(
        route = "dashboard",
        labelRes = R.string.dashboard,
        subtitleRes = R.string.dashboard_subtitle,
        icon = Icons.Rounded.Dashboard,
    ),
    MainDestination(
        route = "input",
        labelRes = R.string.input_center,
        subtitleRes = R.string.input_subtitle,
        icon = Icons.Rounded.EditNote,
    ),
    MainDestination(
        route = "plan",
        labelRes = R.string.action_plan,
        subtitleRes = R.string.action_plan_subtitle,
        icon = Icons.Rounded.CalendarMonth,
    ),
    MainDestination(
        route = "history",
        labelRes = R.string.history,
        subtitleRes = R.string.history_subtitle,
        icon = Icons.Rounded.History,
    ),
)

private const val ChatRoute = "krishi_ai"

@Composable
fun RaithaApp(
    appContainer: AppContainer,
) {
    val farmerProfile by appContainer.farmerRepository.profile.collectAsStateWithLifecycle(initialValue = null)

    LaunchedEffect(farmerProfile?.languageTag) {
        val languageTag = farmerProfile?.languageTag ?: return@LaunchedEffect
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(languageTag))
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        if (farmerProfile == null) {
            OnboardingRoute(appContainer = appContainer)
        } else {
            MainShell(appContainer = appContainer)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainShell(
    appContainer: AppContainer,
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: mainDestinations.first().route
    val currentDestination = mainDestinations.firstOrNull { it.route == currentRoute } ?: mainDestinations.first()
    val isChatRoute = currentRoute == ChatRoute

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    if (isChatRoute) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowBack,
                                contentDescription = null,
                            )
                        }
                    }
                },
                title = {
                    Column {
                        Text(
                            text = if (isChatRoute) {
                                stringResource(R.string.krishi_ai)
                            } else {
                                stringResource(currentDestination.labelRes)
                            },
                        )
                        Text(
                            text = if (isChatRoute) {
                                stringResource(R.string.chat_subtitle)
                            } else {
                                stringResource(currentDestination.subtitleRes)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
            )
        },
        bottomBar = {
            if (!isChatRoute) {
                NavigationBar {
                    mainDestinations.forEach { destination ->
                        NavigationBarItem(
                            selected = currentRoute == destination.route,
                            onClick = {
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = destination.icon,
                                    contentDescription = null,
                                )
                            },
                            label = {
                                Text(text = stringResource(destination.labelRes))
                            },
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (currentRoute == "dashboard") {
                FloatingActionButton(
                    onClick = { navController.navigate(ChatRoute) },
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SmartToy,
                        contentDescription = stringResource(R.string.ask_krishi_ai),
                    )
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = mainDestinations.first().route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable("dashboard") {
                DashboardRoute(appContainer = appContainer)
            }
            composable("input") {
                InputCenterRoute(appContainer = appContainer)
            }
            composable("plan") {
                ActionPlanRoute(appContainer = appContainer)
            }
            composable("history") {
                HistoryRoute(appContainer = appContainer)
            }
            composable(ChatRoute) {
                KrishiAiChatRoute(appContainer = appContainer)
            }
        }
    }
}
