package com.raithabharosa.hub.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmerProfileDao {
    @Query("SELECT * FROM farmer_profiles WHERE id = 1 LIMIT 1")
    fun observeProfile(): Flow<FarmerProfile?>

    @Upsert
    suspend fun upsert(profile: FarmerProfile)
}

