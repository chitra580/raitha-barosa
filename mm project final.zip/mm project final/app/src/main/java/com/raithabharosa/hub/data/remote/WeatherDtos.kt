package com.raithabharosa.hub.data.remote

data class OpenWeatherResponse(
    val main: WeatherMainDto,
    val weather: List<WeatherDescriptionDto>,
    val name: String,
)

data class WeatherMainDto(
    val temp: Double,
    val humidity: Int,
)

data class WeatherDescriptionDto(
    val description: String,
)

