package com.raithabharosa.hub.ui.screen

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raithabharosa.hub.R
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.model.AgricultureQuickAction
import com.raithabharosa.hub.data.model.ChatMessage
import com.raithabharosa.hub.data.model.ChatRole
import com.raithabharosa.hub.data.model.FarmAdviceContext
import com.raithabharosa.hub.data.model.WeatherSignal
import com.raithabharosa.hub.ui.theme.SoftGreen
import com.raithabharosa.hub.ui.theme.SoftRed
import com.raithabharosa.hub.ui.theme.SoftYellow
import com.raithabharosa.hub.ui.util.cropLabelRes
import com.raithabharosa.hub.viewmodel.ChatUiState
import com.raithabharosa.hub.viewmodel.ChatViewModel
import java.util.Locale

@Composable
fun KrishiAiChatRoute(
    appContainer: AppContainer,
) {
    val viewModel: ChatViewModel = viewModel(
        factory = ChatViewModel.factory(appContainer),
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    KrishiAiChatScreen(
        uiState = uiState,
        onInputChange = viewModel::updateInputText,
        onSendMessage = viewModel::sendMessage,
        onQuickAction = viewModel::runQuickAction,
        onToggleTts = viewModel::toggleTts,
    )
}

@Composable
private fun KrishiAiChatScreen(
    uiState: ChatUiState,
    onInputChange: (String) -> Unit,
    onSendMessage: () -> Unit,
    onQuickAction: (AgricultureQuickAction) -> Unit,
    onToggleTts: () -> Unit,
) {
    val context = LocalContext.current
    var ttsReady by remember { mutableStateOf(false) }
    var lastSpokenMessageId by remember { mutableLongStateOf(-1L) }
    val textToSpeech = remember(context) {
        TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
        }
    }

    DisposableEffect(textToSpeech) {
        onDispose {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
    }

    LaunchedEffect(uiState.ttsEnabled, uiState.messages) {
        val latestAssistantMessage = uiState.messages.lastOrNull { it.role == ChatRole.ASSISTANT } ?: return@LaunchedEffect
        if (!uiState.ttsEnabled || !ttsReady || latestAssistantMessage.id == lastSpokenMessageId) {
            return@LaunchedEffect
        }

        textToSpeech.language = if (uiState.currentContext?.languageTag == "kn") {
            Locale("kn", "IN")
        } else {
            Locale.US
        }
        textToSpeech.speak(
            buildSpeechText(latestAssistantMessage),
            TextToSpeech.QUEUE_FLUSH,
            null,
            latestAssistantMessage.id.toString(),
        )
        lastSpokenMessageId = latestAssistantMessage.id
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        ContextBanner(context = uiState.currentContext)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.fast_actions),
                style = MaterialTheme.typography.titleLarge,
            )
            AssistChip(
                onClick = onToggleTts,
                leadingIcon = {
                    Icon(
                        imageVector = if (uiState.ttsEnabled) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff,
                        contentDescription = null,
                    )
                },
                label = {
                    Text(
                        if (uiState.ttsEnabled) {
                            stringResource(R.string.voice_on)
                        } else {
                            stringResource(R.string.voice_off)
                        },
                    )
                },
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            QuickActionCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.Spa,
                label = stringResource(R.string.sowing_advice),
                onClick = { onQuickAction(AgricultureQuickAction.SOWING_ADVICE) },
            )
            QuickActionCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.Cloud,
                label = stringResource(R.string.rain_warning),
                onClick = { onQuickAction(AgricultureQuickAction.RAIN_WARNING) },
            )
            QuickActionCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.Inventory2,
                label = stringResource(R.string.fertilizer_dose),
                onClick = { onQuickAction(AgricultureQuickAction.FERTILIZER_DOSE) },
            )
        }

        if (uiState.isSending) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(uiState.messages, key = { it.id }) { message ->
                ChatBubble(message = message)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            OutlinedTextField(
                value = uiState.inputText,
                onValueChange = onInputChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.chat_input_hint)) },
                shape = RoundedCornerShape(20.dp),
                maxLines = 3,
            )
            FilledIconButton(
                onClick = onSendMessage,
                modifier = Modifier.size(52.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Send,
                    contentDescription = stringResource(R.string.send_message),
                )
            }
        }
    }
}

@Composable
private fun ContextBanner(
    context: FarmAdviceContext?,
) {
    if (context == null) {
        return
    }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.elevatedCardColors(containerColor = SoftGreen),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = stringResource(R.string.context_snapshot),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = stringResource(cropLabelRes(context.cropKey)),
                style = MaterialTheme.typography.bodyLarge,
            )
            Text(
                text = stringResource(R.string.soil_context_template, context.soilMoisture, context.sowingIndex),
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                text = stringResource(R.string.weather_signal_template, weatherSignalLabel(context.weatherSignal)),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun QuickActionCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    ElevatedCard(
        modifier = modifier,
        onClick = onClick,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(28.dp),
            )
            Text(
                text = label,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

@Composable
private fun ChatBubble(
    message: ChatMessage,
) {
    val isUser = message.role == ChatRole.USER
    val bubbleColor = if (isUser) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    val textColor = if (isUser) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSurface
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        Surface(
            modifier = Modifier
                .align(if (isUser) Alignment.CenterEnd else Alignment.CenterStart)
                .fillMaxWidth(0.86f),
            color = bubbleColor,
            shape = RoundedCornerShape(22.dp),
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = message.text,
                    color = textColor,
                    style = MaterialTheme.typography.bodyLarge,
                )

                if (message.alert != null) {
                    ElevatedCard(
                        colors = CardDefaults.elevatedCardColors(containerColor = SoftRed),
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(
                                text = message.alert.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = message.alert.summary,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun weatherSignalLabel(signal: WeatherSignal): String = when (signal) {
    WeatherSignal.RAIN -> stringResource(R.string.weather_rain)
    WeatherSignal.SUN -> stringResource(R.string.weather_sun)
    WeatherSignal.CLOUD -> stringResource(R.string.weather_cloud)
}

private fun buildSpeechText(message: ChatMessage): String = buildString {
    append(message.text)
    message.alert?.let {
        append(' ')
        append(it.title)
        append(". ")
        append(it.summary)
    }
}
