package com.raithabharosa.hub.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.model.InsightTone
import com.raithabharosa.hub.data.model.SoilStatus
import com.raithabharosa.hub.data.model.SowingInsight
import com.raithabharosa.hub.data.model.WeatherSnapshot
import com.raithabharosa.hub.data.model.WeatherSource
import com.raithabharosa.hub.data.model.calculateSowingInsight
import com.raithabharosa.hub.data.model.toSoilStatus
import com.raithabharosa.hub.data.repository.FarmerRepository
import com.raithabharosa.hub.data.repository.SoilRepository
import com.raithabharosa.hub.data.repository.WeatherRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val DefaultSoilStatus = SoilStatus(
    moistureLevel = 27,
    nitrogen = 55,
    phosphorus = 42,
    potassium = 61,
)

private val DefaultWeather = WeatherSnapshot(
    temperatureCelsius = 28,
    humidity = 68,
    description = "Partly cloudy",
    locationLabel = "Mandya, Karnataka",
    source = WeatherSource.MOCK,
)

data class DashboardUiState(
    val farmerName: String = "",
    val primaryCrop: String = "",
    val soilStatus: SoilStatus = DefaultSoilStatus,
    val weather: WeatherSnapshot = DefaultWeather,
    val sowingInsight: SowingInsight = calculateSowingInsight(
        moistureLevel = DefaultSoilStatus.moistureLevel,
        humidity = DefaultWeather.humidity,
    ),
)

class DashboardViewModel(
    farmerRepository: FarmerRepository,
    private val soilRepository: SoilRepository,
    private val weatherRepository: WeatherRepository,
) : ViewModel() {
    private val generatedSoilStatus = MutableStateFlow(soilRepository.generateCurrentStatus())
    private val weatherState = MutableStateFlow(DefaultWeather)

    val uiState: StateFlow<DashboardUiState> = combine(
        farmerRepository.profile,
        soilRepository.latestLog,
        generatedSoilStatus,
        weatherState,
    ) { profile, latestLog, generatedStatus, weather ->
        val currentSoil = latestLog?.toSoilStatus() ?: generatedStatus

        DashboardUiState(
            farmerName = profile?.name.orEmpty(),
            primaryCrop = profile?.primaryCrop.orEmpty(),
            soilStatus = currentSoil,
            weather = weather,
            sowingInsight = calculateSowingInsight(
                moistureLevel = currentSoil.moistureLevel,
                humidity = weather.humidity,
            ),
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardUiState(),
    )

    init {
        refreshWeather()
    }

    fun refreshWeather() {
        viewModelScope.launch {
            weatherState.value = weatherRepository.getCurrentWeather()
        }
    }

    fun simulateCurrentStatus() {
        generatedSoilStatus.value = soilRepository.generateCurrentStatus()
    }

    companion object {
        fun factory(appContainer: AppContainer) = viewModelFactory {
            initializer {
                DashboardViewModel(
                    farmerRepository = appContainer.farmerRepository,
                    soilRepository = appContainer.soilRepository,
                    weatherRepository = appContainer.weatherRepository,
                )
            }
        }
    }
}
