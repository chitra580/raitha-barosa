package com.raithabharosa.hub.data.repository

import com.raithabharosa.hub.data.local.FarmerProfile
import com.raithabharosa.hub.data.local.FarmerProfileDao
import kotlinx.coroutines.flow.Flow

class FarmerRepository(
    private val farmerProfileDao: FarmerProfileDao,
) {
    val profile: Flow<FarmerProfile?> = farmerProfileDao.observeProfile()

    suspend fun saveProfile(
        name: String,
        primaryCrop: String,
        languageTag: String,
    ) {
        farmerProfileDao.upsert(
            FarmerProfile(
                name = name.trim(),
                primaryCrop = primaryCrop,
                languageTag = languageTag,
            ),
        )
    }
}

