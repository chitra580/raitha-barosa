package com.raithabharosa.hub.data.model

data class FarmAdviceContext(
    val cropKey: String,
    val languageTag: String,
    val soilMoisture: Int,
    val sowingIndex: Int,
    val weatherSignal: WeatherSignal,
    val weatherLabel: String,
    val nitrogen: Int,
    val phosphorus: Int,
    val potassium: Int,
    val hasStoredLog: Boolean,
)

data class AiAdvice(
    val text: String,
    val alert: ChatAlert? = null,
)

data class ChatAlert(
    val title: String,
    val summary: String,
)

data class ChatMessage(
    val id: Long,
    val role: ChatRole,
    val text: String,
    val alert: ChatAlert? = null,
)

enum class ChatRole {
    USER,
    ASSISTANT,
}

enum class AgricultureQuickAction {
    SOWING_ADVICE,
    RAIN_WARNING,
    FERTILIZER_DOSE,
}

enum class WeatherSignal {
    RAIN,
    SUN,
    CLOUD,
}

