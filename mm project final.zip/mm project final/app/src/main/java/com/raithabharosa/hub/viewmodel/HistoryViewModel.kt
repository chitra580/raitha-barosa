package com.raithabharosa.hub.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.local.SoilDataLog
import com.raithabharosa.hub.data.repository.SoilRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HistoryUiState(
    val logs: List<SoilDataLog> = emptyList(),
)

class HistoryViewModel(
    private val soilRepository: SoilRepository,
) : ViewModel() {
    val uiState: StateFlow<HistoryUiState> = soilRepository.logs
        .map { logs -> HistoryUiState(logs = logs) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = HistoryUiState(),
        )

    fun deleteLog(id: Long) {
        viewModelScope.launch {
            soilRepository.deleteLog(id)
        }
    }

    companion object {
        fun factory(appContainer: AppContainer) = viewModelFactory {
            initializer {
                HistoryViewModel(appContainer.soilRepository)
            }
        }
    }
}
