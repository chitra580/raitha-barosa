package com.raithabharosa.hub

import android.app.Application
import com.raithabharosa.hub.data.AppContainer

class RaithaBharosaApplication : Application() {
    val container: AppContainer by lazy { AppContainer(this) }
}

