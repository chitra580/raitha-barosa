package com.raithabharosa.hub.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.repository.SoilRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class InputCenterUiState(
    val nitrogen: Int = 50,
    val phosphorus: Int = 40,
    val potassium: Int = 60,
    val moistureLevel: Int? = null,
    val isSaving: Boolean = false,
    val lastSavedAt: Long? = null,
)

class InputCenterViewModel(
    private val soilRepository: SoilRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(InputCenterUiState())
    val uiState: StateFlow<InputCenterUiState> = _uiState.asStateFlow()

    fun updateNitrogen(value: Int) {
        _uiState.update { it.copy(nitrogen = value) }
    }

    fun updatePhosphorus(value: Int) {
        _uiState.update { it.copy(phosphorus = value) }
    }

    fun updatePotassium(value: Int) {
        _uiState.update { it.copy(potassium = value) }
    }

    fun readFieldMoisture() {
        val reading = soilRepository.generateCurrentStatus()
        _uiState.update { it.copy(moistureLevel = reading.moistureLevel) }
    }

    fun saveLog() {
        val state = uiState.value
        val moisture = state.moistureLevel ?: soilRepository.generateCurrentStatus().moistureLevel

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            soilRepository.saveManualLog(
                moistureLevel = moisture,
                nitrogen = state.nitrogen,
                phosphorus = state.phosphorus,
                potassium = state.potassium,
            )
            _uiState.update {
                it.copy(
                    isSaving = false,
                    moistureLevel = moisture,
                    lastSavedAt = System.currentTimeMillis(),
                )
            }
        }
    }

    companion object {
        fun factory(appContainer: AppContainer) = viewModelFactory {
            initializer {
                InputCenterViewModel(appContainer.soilRepository)
            }
        }
    }
}

