package com.raithabharosa.hub.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.raithabharosa.hub.R
import com.raithabharosa.hub.data.model.InsightTone
import com.raithabharosa.hub.ui.theme.LeafGreen
import com.raithabharosa.hub.ui.theme.MilletGold

@Composable
fun SowingIndexGauge(
    score: Int,
    tone: InsightTone,
    modifier: Modifier = Modifier,
) {
    val progress = (score.coerceIn(0, 100) / 100f)
    val indicatorColor = when (tone) {
        InsightTone.OPTIMAL -> LeafGreen
        InsightTone.CAUTION -> MilletGold
        InsightTone.STOP -> MaterialTheme.colorScheme.error
    }
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val label = when (tone) {
        InsightTone.OPTIMAL -> stringResource(R.string.optimal)
        InsightTone.CAUTION -> stringResource(R.string.caution)
        InsightTone.STOP -> stringResource(R.string.stop_activity)
    }

    Box(
        modifier = modifier.aspectRatio(1f),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 16.dp.toPx(), cap = StrokeCap.Round)
            drawArc(
                color = trackColor,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                style = stroke,
            )
            drawArc(
                color = indicatorColor,
                startAngle = 135f,
                sweepAngle = 270f * progress,
                useCenter = false,
                style = stroke,
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = stringResource(R.string.score_template, score),
                style = MaterialTheme.typography.headlineMedium,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}
