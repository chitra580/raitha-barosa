package com.raithabharosa.hub.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.model.AgricultureQuickAction
import com.raithabharosa.hub.data.model.ChatMessage
import com.raithabharosa.hub.data.model.ChatRole
import com.raithabharosa.hub.data.model.FarmAdviceContext
import com.raithabharosa.hub.data.model.WeatherSignal
import com.raithabharosa.hub.data.model.calculateSowingInsight
import com.raithabharosa.hub.data.model.toSoilStatus
import com.raithabharosa.hub.data.prompt.agronomistSystemInstruction
import com.raithabharosa.hub.data.prompt.buildAgronomyPrompt
import com.raithabharosa.hub.data.repository.AgronomyAdvisorRepository
import com.raithabharosa.hub.data.repository.FarmerRepository
import com.raithabharosa.hub.data.repository.SoilRepository
import com.raithabharosa.hub.data.repository.WeatherRepository
import com.raithabharosa.hub.ui.util.CropCatalog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val inputText: String = "",
    val messages: List<ChatMessage> = listOf(
        ChatMessage(
            id = 0,
            role = ChatRole.ASSISTANT,
            text = "Ask about sowing, rainfall, fertilizer dose, or crop health.",
        ),
    ),
    val currentContext: FarmAdviceContext? = null,
    val isSending: Boolean = false,
    val ttsEnabled: Boolean = false,
)

class ChatViewModel(
    private val farmerRepository: FarmerRepository,
    private val soilRepository: SoilRepository,
    private val weatherRepository: WeatherRepository,
    private val agronomyAdvisorRepository: AgronomyAdvisorRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var nextMessageId = 1L

    init {
        refreshContextSnapshot()
    }

    fun updateInputText(value: String) {
        _uiState.update { it.copy(inputText = value) }
    }

    fun toggleTts() {
        _uiState.update { it.copy(ttsEnabled = !it.ttsEnabled) }
    }

    fun runQuickAction(action: AgricultureQuickAction) {
        val question = when (action) {
            AgricultureQuickAction.SOWING_ADVICE -> "Can I sow today?"
            AgricultureQuickAction.RAIN_WARNING -> "Is there any rain warning for my field work?"
            AgricultureQuickAction.FERTILIZER_DOSE -> "What fertilizer dose should I focus on today?"
        }
        sendMessage(question)
    }

    fun sendMessage(rawQuestion: String = uiState.value.inputText) {
        val question = rawQuestion.trim()
        if (question.isBlank() || uiState.value.isSending) {
            return
        }

        val userMessage = ChatMessage(
            id = nextMessageId++,
            role = ChatRole.USER,
            text = question,
        )

        _uiState.update {
            it.copy(
                inputText = "",
                isSending = true,
                messages = it.messages + userMessage,
            )
        }

        viewModelScope.launch {
            val context = buildFarmContext()
            val contextualPrompt = buildContextualPrompt(question)
            val advice = agronomyAdvisorRepository.requestAdvice(
                systemInstruction = agronomistSystemInstruction,
                contextualPrompt = contextualPrompt,
                userQuestion = question,
                context = context,
            )

            _uiState.update {
                it.copy(
                    currentContext = context,
                    isSending = false,
                    messages = it.messages + ChatMessage(
                        id = nextMessageId++,
                        role = ChatRole.ASSISTANT,
                        text = advice.text,
                        alert = advice.alert,
                    ),
                )
            }
        }
    }

    suspend fun buildContextualPrompt(userQuestion: String): String {
        val context = buildFarmContext()
        _uiState.update { it.copy(currentContext = context) }
        return buildAgronomyPrompt(userQuestion = userQuestion, context = context)
    }

    private fun refreshContextSnapshot() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(currentContext = buildFarmContext())
            }
        }
    }

    private suspend fun buildFarmContext(): FarmAdviceContext {
        val profile = farmerRepository.profile.first()
        val latestLog = soilRepository.latestLog.first()
        val currentSoil = latestLog?.toSoilStatus() ?: soilRepository.generateCurrentStatus()
        val weather = weatherRepository.getCurrentWeather()
        val sowingInsight = calculateSowingInsight(
            moistureLevel = currentSoil.moistureLevel,
            humidity = weather.humidity,
        )

        return FarmAdviceContext(
            cropKey = profile?.primaryCrop ?: CropCatalog.SUGARCANE,
            languageTag = profile?.languageTag ?: "en",
            soilMoisture = currentSoil.moistureLevel,
            sowingIndex = sowingInsight.score,
            weatherSignal = when {
                weather.description.contains("rain", ignoreCase = true) ||
                    weather.description.contains("storm", ignoreCase = true) -> WeatherSignal.RAIN
                weather.description.contains("sun", ignoreCase = true) ||
                    weather.description.contains("clear", ignoreCase = true) -> WeatherSignal.SUN
                else -> WeatherSignal.CLOUD
            },
            weatherLabel = weather.description,
            nitrogen = currentSoil.nitrogen,
            phosphorus = currentSoil.phosphorus,
            potassium = currentSoil.potassium,
            hasStoredLog = latestLog != null,
        )
    }

    companion object {
        fun factory(appContainer: AppContainer) = viewModelFactory {
            initializer {
                ChatViewModel(
                    farmerRepository = appContainer.farmerRepository,
                    soilRepository = appContainer.soilRepository,
                    weatherRepository = appContainer.weatherRepository,
                    agronomyAdvisorRepository = appContainer.agronomyAdvisorRepository,
                )
            }
        }
    }
}
