package com.raithabharosa.hub.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raithabharosa.hub.R
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.viewmodel.InputCenterUiState
import com.raithabharosa.hub.viewmodel.InputCenterViewModel
import kotlin.math.roundToInt

@Composable
fun InputCenterRoute(
    appContainer: AppContainer,
) {
    val viewModel: InputCenterViewModel = viewModel(
        factory = InputCenterViewModel.factory(appContainer),
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    InputCenterScreen(
        uiState = uiState,
        onNitrogenChange = viewModel::updateNitrogen,
        onPhosphorusChange = viewModel::updatePhosphorus,
        onPotassiumChange = viewModel::updatePotassium,
        onReadMoisture = viewModel::readFieldMoisture,
        onSaveLog = viewModel::saveLog,
    )
}

@Composable
private fun InputCenterScreen(
    uiState: InputCenterUiState,
    onNitrogenChange: (Int) -> Unit,
    onPhosphorusChange: (Int) -> Unit,
    onPotassiumChange: (Int) -> Unit,
    onReadMoisture: () -> Unit,
    onSaveLog: () -> Unit,
) {
    LazyColumn(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = stringResource(R.string.field_profile),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        text = uiState.moistureLevel?.let {
                            stringResource(R.string.moisture_template, it)
                        } ?: stringResource(R.string.field_moisture_pending),
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    AssistChip(
                        onClick = onReadMoisture,
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.WaterDrop,
                                contentDescription = null,
                            )
                        },
                        label = { Text(stringResource(R.string.read_field_moisture)) },
                    )
                    Text(
                        text = stringResource(R.string.sensor_note),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        item {
            MetricSlider(
                label = stringResource(R.string.nitrogen_label),
                value = uiState.nitrogen,
                onValueChange = onNitrogenChange,
            )
        }

        item {
            MetricSlider(
                label = stringResource(R.string.phosphorus_label),
                value = uiState.phosphorus,
                onValueChange = onPhosphorusChange,
            )
        }

        item {
            MetricSlider(
                label = stringResource(R.string.potassium_label),
                value = uiState.potassium,
                onValueChange = onPotassiumChange,
            )
        }

        item {
            Button(
                onClick = onSaveLog,
                enabled = !uiState.isSaving,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(stringResource(R.string.save_log))
            }
        }

        if (uiState.lastSavedAt != null) {
            item {
                AssistChip(
                    onClick = {},
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = null,
                        )
                    },
                    label = { Text(stringResource(R.string.saved_locally)) },
                )
            }
        }
    }
}

@Composable
private fun MetricSlider(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit,
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = "$label: $value",
                style = MaterialTheme.typography.titleMedium,
            )
            Slider(
                value = value.toFloat(),
                onValueChange = { onValueChange(it.roundToInt()) },
                valueRange = 0f..100f,
            )
        }
    }
}
