package com.raithabharosa.hub.ui.theme

import androidx.compose.ui.graphics.Color

val LeafGreen = Color(0xFF2E5530)
val DeepLeaf = Color(0xFF234226)
val SoilBrown = Color(0xFF7A5230)
val MilletGold = Color(0xFFC9A46B)
val Sand = Color(0xFFF7F1E6)
val CloudMist = Color(0xFFE9F1E6)
val SoftRed = Color(0xFFF6D2CB)
val SoftYellow = Color(0xFFF8E8B3)
val SoftGreen = Color(0xFFD9EFD1)
val Bark = Color(0xFF4F3422)
val OffWhite = Color(0xFFFFFBF5)

