package com.raithabharosa.hub.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "soil_data_logs")
data class SoilDataLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val moistureLevel: Int,
    val nitrogen: Int,
    val phosphorus: Int,
    val potassium: Int,
)

