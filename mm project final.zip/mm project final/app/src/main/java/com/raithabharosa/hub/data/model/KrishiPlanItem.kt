package com.raithabharosa.hub.data.model

import java.time.LocalDate

data class KrishiPlanItem(
    val date: LocalDate,
    val condition: String,
    val recommendedActivity: String,
    val riskLevel: InsightTone,
    val warningMessage: String? = null,
)

