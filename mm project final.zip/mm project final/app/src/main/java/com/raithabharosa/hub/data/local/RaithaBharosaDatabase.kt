package com.raithabharosa.hub.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [FarmerProfile::class, SoilDataLog::class],
    version = 1,
    exportSchema = false,
)
abstract class RaithaBharosaDatabase : RoomDatabase() {
    abstract fun farmerProfileDao(): FarmerProfileDao
    abstract fun soilDataLogDao(): SoilDataLogDao
}

