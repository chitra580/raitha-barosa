package com.raithabharosa.hub.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.repository.FarmerRepository
import com.raithabharosa.hub.ui.util.CropCatalog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OnboardingUiState(
    val farmerName: String = "",
    val selectedCrop: String = CropCatalog.SUGARCANE,
    val selectedLanguageTag: String = "en",
    val isSaving: Boolean = false,
    val showValidationError: Boolean = false,
) {
    val canContinue: Boolean
        get() = farmerName.isNotBlank()
}

class OnboardingViewModel(
    private val farmerRepository: FarmerRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(OnboardingUiState())
    val uiState: StateFlow<OnboardingUiState> = _uiState.asStateFlow()

    fun updateFarmerName(name: String) {
        _uiState.update {
            it.copy(
                farmerName = name,
                showValidationError = false,
            )
        }
    }

    fun updateSelectedCrop(crop: String) {
        _uiState.update { it.copy(selectedCrop = crop) }
    }

    fun updateSelectedLanguage(languageTag: String) {
        _uiState.update { it.copy(selectedLanguageTag = languageTag) }
    }

    fun saveProfile() {
        val state = uiState.value
        if (!state.canContinue) {
            _uiState.update { it.copy(showValidationError = true) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            farmerRepository.saveProfile(
                name = state.farmerName,
                primaryCrop = state.selectedCrop,
                languageTag = state.selectedLanguageTag,
            )
            _uiState.update { it.copy(isSaving = false) }
        }
    }

    companion object {
        fun factory(appContainer: AppContainer) = viewModelFactory {
            initializer {
                OnboardingViewModel(appContainer.farmerRepository)
            }
        }
    }
}

