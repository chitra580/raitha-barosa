package com.raithabharosa.hub.data

import android.content.Context
import androidx.room.Room
import com.raithabharosa.hub.BuildConfig
import com.raithabharosa.hub.data.local.RaithaBharosaDatabase
import com.raithabharosa.hub.data.remote.OpenWeatherService
import com.raithabharosa.hub.data.repository.LocalAgronomyAdvisorRepository
import com.raithabharosa.hub.data.repository.AgronomyAdvisorRepository
import com.raithabharosa.hub.data.repository.FarmerRepository
import com.raithabharosa.hub.data.repository.SoilRepository
import com.raithabharosa.hub.data.repository.WeatherRepository
import com.raithabharosa.hub.data.simulation.DataGenerator
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class AppContainer(context: Context) {
    private val database = Room.databaseBuilder(
        context.applicationContext,
        RaithaBharosaDatabase::class.java,
        "raitha_bharosa.db",
    ).build()

    private val openWeatherService = Retrofit.Builder()
        .baseUrl("https://api.openweathermap.org/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(OpenWeatherService::class.java)

    val farmerRepository = FarmerRepository(database.farmerProfileDao())
    val soilRepository = SoilRepository(
        soilDataLogDao = database.soilDataLogDao(),
        dataGenerator = DataGenerator(),
    )
    val agronomyAdvisorRepository: AgronomyAdvisorRepository = LocalAgronomyAdvisorRepository()
    val weatherRepository = WeatherRepository(
        openWeatherService = openWeatherService,
        apiKey = BuildConfig.OPEN_WEATHER_API_KEY,
    )
}
