package com.raithabharosa.hub.data.model

import com.raithabharosa.hub.data.local.SoilDataLog

data class SoilStatus(
    val moistureLevel: Int,
    val nitrogen: Int,
    val phosphorus: Int,
    val potassium: Int,
    val timestamp: Long = System.currentTimeMillis(),
)

fun SoilStatus.toEntity(): SoilDataLog = SoilDataLog(
    timestamp = timestamp,
    moistureLevel = moistureLevel,
    nitrogen = nitrogen,
    phosphorus = phosphorus,
    potassium = potassium,
)

fun SoilDataLog.toSoilStatus(): SoilStatus = SoilStatus(
    moistureLevel = moistureLevel,
    nitrogen = nitrogen,
    phosphorus = phosphorus,
    potassium = potassium,
    timestamp = timestamp,
)

