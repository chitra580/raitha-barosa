package com.raithabharosa.hub.data.model

data class WeatherSnapshot(
    val temperatureCelsius: Int,
    val humidity: Int,
    val description: String,
    val locationLabel: String,
    val source: WeatherSource,
)

enum class WeatherSource {
    LIVE,
    MOCK,
}

