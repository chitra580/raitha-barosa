package com.raithabharosa.hub.data.repository

import com.raithabharosa.hub.data.model.WeatherSnapshot
import com.raithabharosa.hub.data.model.WeatherSource
import com.raithabharosa.hub.data.remote.OpenWeatherService
import kotlin.math.roundToInt

class WeatherRepository(
    private val openWeatherService: OpenWeatherService,
    private val apiKey: String,
) {
    suspend fun getCurrentWeather(
        cityQuery: String = "Mandya,IN",
        locationLabel: String = "Mandya, Karnataka",
    ): WeatherSnapshot {
        if (apiKey.isBlank()) {
            return mockWeather(locationLabel)
        }

        return runCatching {
            val response = openWeatherService.fetchCurrentWeather(
                city = cityQuery,
                apiKey = apiKey,
            )

            WeatherSnapshot(
                temperatureCelsius = response.main.temp.roundToInt(),
                humidity = response.main.humidity,
                description = response.weather.firstOrNull()?.description ?: "Clear sky",
                locationLabel = response.name.ifBlank { locationLabel },
                source = WeatherSource.LIVE,
            )
        }.getOrElse {
            mockWeather(locationLabel)
        }
    }

    private fun mockWeather(locationLabel: String): WeatherSnapshot = WeatherSnapshot(
        temperatureCelsius = 28,
        humidity = 68,
        description = "Partly cloudy",
        locationLabel = locationLabel,
        source = WeatherSource.MOCK,
    )
}

