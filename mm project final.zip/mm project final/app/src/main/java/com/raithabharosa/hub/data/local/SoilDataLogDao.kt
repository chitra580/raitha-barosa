package com.raithabharosa.hub.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SoilDataLogDao {
    @Query("SELECT * FROM soil_data_logs ORDER BY timestamp DESC")
    fun observeAllLogs(): Flow<List<SoilDataLog>>

    @Query("SELECT * FROM soil_data_logs ORDER BY timestamp DESC LIMIT 1")
    fun observeLatestLog(): Flow<SoilDataLog?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: SoilDataLog)

    @Query("DELETE FROM soil_data_logs WHERE id = :id")
    suspend fun deleteById(id: Long)
}

