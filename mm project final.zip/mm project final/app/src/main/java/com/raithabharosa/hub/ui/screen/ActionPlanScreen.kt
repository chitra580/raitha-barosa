package com.raithabharosa.hub.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raithabharosa.hub.R
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.model.InsightTone
import com.raithabharosa.hub.data.model.KrishiPlanItem
import com.raithabharosa.hub.ui.theme.SoftGreen
import com.raithabharosa.hub.ui.theme.SoftRed
import com.raithabharosa.hub.ui.theme.SoftYellow
import com.raithabharosa.hub.ui.util.cropLabelRes
import com.raithabharosa.hub.ui.util.formatPlanDate
import com.raithabharosa.hub.viewmodel.ActionPlanUiState
import com.raithabharosa.hub.viewmodel.ActionPlanViewModel

@Composable
fun ActionPlanRoute(
    appContainer: AppContainer,
) {
    val viewModel: ActionPlanViewModel = viewModel(
        factory = ActionPlanViewModel.factory(appContainer),
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    ActionPlanScreen(uiState = uiState)
}

@Composable
private fun ActionPlanScreen(
    uiState: ActionPlanUiState,
) {
    LazyColumn(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = stringResource(R.string.krishi_calendar),
                        style = MaterialTheme.typography.headlineMedium,
                    )
                    Text(
                        text = stringResource(cropLabelRes(uiState.primaryCrop)),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        items(uiState.items) { item ->
            PlanCard(item = item)
        }
    }
}

@Composable
private fun PlanCard(
    item: KrishiPlanItem,
) {
    val containerColor = when (item.riskLevel) {
        InsightTone.OPTIMAL -> SoftGreen
        InsightTone.CAUTION -> SoftYellow
        InsightTone.STOP -> SoftRed
    }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.elevatedCardColors(containerColor = containerColor),
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = iconForCondition(item.condition),
                    contentDescription = null,
                )
                Column {
                    Text(
                        text = formatPlanDate(item.date),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        text = item.condition,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }

            Text(
                text = stringResource(R.string.recommended_activity),
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                text = item.recommendedActivity,
                style = MaterialTheme.typography.bodyLarge,
            )

            if (item.warningMessage != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Warning,
                        contentDescription = null,
                    )
                    Text(
                        text = item.warningMessage,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
    }
}

private fun iconForCondition(condition: String): ImageVector = when {
    condition.contains("storm", ignoreCase = true) -> Icons.Rounded.Bolt
    condition.contains("rain", ignoreCase = true) -> Icons.Rounded.WaterDrop
    condition.contains("sun", ignoreCase = true) -> Icons.Rounded.WbSunny
    else -> Icons.Rounded.Cloud
}
