package com.raithabharosa.hub.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "farmer_profiles")
data class FarmerProfile(
    @PrimaryKey
    val id: Int = DEFAULT_PROFILE_ID,
    val name: String,
    val primaryCrop: String,
    val languageTag: String,
) {
    companion object {
        const val DEFAULT_PROFILE_ID = 1
    }
}

