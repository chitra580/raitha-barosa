package com.raithabharosa.hub.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raithabharosa.hub.R
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.ui.theme.CloudMist
import com.raithabharosa.hub.ui.theme.MilletGold
import com.raithabharosa.hub.ui.theme.Sand
import com.raithabharosa.hub.ui.util.CropCatalog
import com.raithabharosa.hub.ui.util.cropLabelRes
import com.raithabharosa.hub.viewmodel.OnboardingUiState
import com.raithabharosa.hub.viewmodel.OnboardingViewModel

@Composable
fun OnboardingRoute(
    appContainer: AppContainer,
) {
    val viewModel: OnboardingViewModel = viewModel(
        factory = OnboardingViewModel.factory(appContainer),
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    OnboardingScreen(
        uiState = uiState,
        onNameChange = viewModel::updateFarmerName,
        onCropChange = viewModel::updateSelectedCrop,
        onLanguageChange = viewModel::updateSelectedLanguage,
        onStartClick = viewModel::saveProfile,
    )
}

@Composable
private fun OnboardingScreen(
    uiState: OnboardingUiState,
    onNameChange: (String) -> Unit,
    onCropChange: (String) -> Unit,
    onLanguageChange: (String) -> Unit,
    onStartClick: () -> Unit,
) {
    var cropMenuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(CloudMist, Sand, MilletGold.copy(alpha = 0.18f)),
                ),
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Text(
                    text = stringResource(R.string.welcome_title),
                    style = MaterialTheme.typography.headlineLarge,
                )
                Text(
                    text = stringResource(R.string.onboarding_subtitle),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.select_language_heading),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FilterChip(
                            selected = uiState.selectedLanguageTag == "en",
                            onClick = { onLanguageChange("en") },
                            label = { Text(stringResource(R.string.english)) },
                        )
                        FilterChip(
                            selected = uiState.selectedLanguageTag == "kn",
                            onClick = { onLanguageChange("kn") },
                            label = { Text(stringResource(R.string.kannada)) },
                        )
                    }
                }

                OutlinedTextField(
                    value = uiState.farmerName,
                    onValueChange = onNameChange,
                    label = { Text(stringResource(R.string.farmer_name)) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.crop_label),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Box {
                        OutlinedButton(
                            onClick = { cropMenuExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(text = stringResource(cropLabelRes(uiState.selectedCrop)))
                                Icon(
                                    imageVector = Icons.Rounded.ArrowDropDown,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = cropMenuExpanded,
                            onDismissRequest = { cropMenuExpanded = false },
                        ) {
                            CropCatalog.all.forEach { crop ->
                                DropdownMenuItem(
                                    text = { Text(stringResource(cropLabelRes(crop))) },
                                    onClick = {
                                        onCropChange(crop)
                                        cropMenuExpanded = false
                                    },
                                )
                            }
                        }
                    }
                }

                if (uiState.showValidationError) {
                    Text(
                        text = stringResource(R.string.farmer_name_error),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                    )
                }

                Button(
                    onClick = onStartClick,
                    enabled = !uiState.isSaving,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                ) {
                    Text(
                        text = stringResource(R.string.start_farming),
                        modifier = Modifier.padding(vertical = 8.dp),
                    )
                }
            }
        }
    }
}

