package com.raithabharosa.hub.data.model

fun calculateSowingInsight(
    moistureLevel: Int,
    humidity: Int,
): SowingInsight {
    val baseInsight = when {
        moistureLevel in 25..30 -> SowingInsight(
            score = 90,
            tone = InsightTone.OPTIMAL,
            statusMessage = "Moisture is ideal for sowing today.",
            quickAction = "Prepare seeds and finish sowing before sunset.",
        )

        moistureLevel > 35 -> SowingInsight(
            score = 30,
            tone = InsightTone.STOP,
            statusMessage = "Soil too wet. Roots may struggle to breathe.",
            quickAction = "Delay sowing and avoid irrigation until the field drains.",
        )

        moistureLevel < 18 -> SowingInsight(
            score = 45,
            tone = InsightTone.CAUTION,
            statusMessage = "Soil is on the dry side for sowing.",
            quickAction = "Apply light irrigation and recheck moisture this evening.",
        )

        else -> SowingInsight(
            score = 68,
            tone = InsightTone.CAUTION,
            statusMessage = "Field conditions are usable but not fully ideal.",
            quickAction = "Test one more patch and sow only the best-drained area.",
        )
    }

    return if (humidity >= 85 && baseInsight.score > 35) {
        baseInsight.copy(
            score = (baseInsight.score - 10).coerceAtLeast(35),
            tone = if (baseInsight.tone == InsightTone.OPTIMAL) {
                InsightTone.CAUTION
            } else {
                baseInsight.tone
            },
            statusMessage = "Air humidity is high, so field drying may slow down.",
            quickAction = "Keep sowing light and watch for standing water overnight.",
        )
    } else {
        baseInsight
    }
}

