package com.raithabharosa.hub.data.simulation

import com.raithabharosa.hub.data.model.SoilStatus
import kotlin.random.Random

class DataGenerator(
    private val random: Random = Random(System.currentTimeMillis()),
) {
    fun generateCurrentStatus(): SoilStatus = SoilStatus(
        moistureLevel = random.nextInt(from = 10, until = 41),
        nitrogen = random.nextInt(from = 20, until = 91),
        phosphorus = random.nextInt(from = 15, until = 81),
        potassium = random.nextInt(from = 25, until = 96),
    )
}
