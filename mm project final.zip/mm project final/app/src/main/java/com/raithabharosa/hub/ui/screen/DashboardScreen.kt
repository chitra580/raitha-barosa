package com.raithabharosa.hub.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raithabharosa.hub.R
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.model.InsightTone
import com.raithabharosa.hub.data.model.WeatherSource
import com.raithabharosa.hub.ui.components.SowingIndexGauge
import com.raithabharosa.hub.ui.theme.SoftGreen
import com.raithabharosa.hub.ui.theme.SoftRed
import com.raithabharosa.hub.ui.theme.SoftYellow
import com.raithabharosa.hub.ui.util.cropLabelRes
import com.raithabharosa.hub.viewmodel.DashboardUiState
import com.raithabharosa.hub.viewmodel.DashboardViewModel
import java.util.Locale

@Composable
fun DashboardRoute(
    appContainer: AppContainer,
) {
    val viewModel: DashboardViewModel = viewModel(
        factory = DashboardViewModel.factory(appContainer),
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    DashboardScreen(
        uiState = uiState,
        onRefreshWeather = viewModel::refreshWeather,
    )
}

@Composable
private fun DashboardScreen(
    uiState: DashboardUiState,
    onRefreshWeather: () -> Unit,
) {
    val insightToneColor = when (uiState.sowingInsight.tone) {
        InsightTone.OPTIMAL -> SoftGreen
        InsightTone.CAUTION -> SoftYellow
        InsightTone.STOP -> SoftRed
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                ),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Text(
                        text = if (uiState.farmerName.isBlank()) {
                            stringResource(R.string.today_focus)
                        } else {
                            "${stringResource(R.string.today_focus)} - ${uiState.farmerName}"
                        },
                        style = MaterialTheme.typography.headlineMedium,
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.MyLocation,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = uiState.weather.locationLabel,
                            style = MaterialTheme.typography.bodyLarge,
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (uiState.primaryCrop.isNotBlank()) {
                            AssistChip(
                                onClick = {},
                                label = { Text(stringResource(cropLabelRes(uiState.primaryCrop))) },
                            )
                        }
                        AssistChip(
                            onClick = {},
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Cloud,
                                    contentDescription = null,
                                )
                            },
                            label = {
                                Text(
                                    text = if (uiState.weather.source == WeatherSource.LIVE) {
                                        stringResource(R.string.source_live)
                                    } else {
                                        stringResource(R.string.source_mock)
                                    },
                                )
                            },
                        )
                    }
                }
            }
        }

        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.elevatedCardColors(containerColor = insightToneColor),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = stringResource(R.string.sowing_index),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    SowingIndexGauge(
                        score = uiState.sowingInsight.score,
                        tone = uiState.sowingInsight.tone,
                        modifier = Modifier.size(220.dp),
                    )
                    Text(
                        text = uiState.sowingInsight.statusMessage,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = stringResource(R.string.weather_status),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        text = stringResource(
                            R.string.weather_template,
                            uiState.weather.temperatureCelsius,
                            uiState.weather.description.replaceFirstChar {
                                if (it.isLowerCase()) {
                                    it.titlecase(Locale.getDefault())
                                } else {
                                    it.toString()
                                }
                            },
                        ),
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Text(
                        text = "${stringResource(R.string.soil_moisture)}: ${stringResource(R.string.moisture_template, uiState.soilStatus.moistureLevel)}",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        text = "${stringResource(R.string.sync_status)}: ${stringResource(R.string.stored_on_device)}",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        text = "${stringResource(R.string.weather_source)}: ${
                            if (uiState.weather.source == WeatherSource.LIVE) {
                                stringResource(R.string.source_live)
                            } else {
                                stringResource(R.string.source_mock)
                            }
                        }",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Button(
                        onClick = onRefreshWeather,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 8.dp),
                        )
                        Text(text = stringResource(R.string.refresh_weather))
                    }
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = stringResource(R.string.quick_action),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        text = uiState.sowingInsight.quickAction,
                        style = MaterialTheme.typography.bodyLarge,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = stringResource(R.string.soil_snapshot),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        text = stringResource(R.string.moisture_template, uiState.soilStatus.moistureLevel),
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Text(
                        text = stringResource(
                            R.string.npk_template,
                            uiState.soilStatus.nitrogen,
                            uiState.soilStatus.phosphorus,
                            uiState.soilStatus.potassium,
                        ),
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            }
        }
    }
}
