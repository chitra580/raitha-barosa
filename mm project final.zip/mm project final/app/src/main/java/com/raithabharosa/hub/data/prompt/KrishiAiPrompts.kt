package com.raithabharosa.hub.data.prompt

import com.raithabharosa.hub.data.model.FarmAdviceContext
import com.raithabharosa.hub.data.model.WeatherSignal

val agronomistSystemInstruction = """
You are the Krishi AI assistant inside Raitha-Bharosa Hub.
Act as a dedicated Krishi Vigyan Kendra (KVK) scientist.
Only answer questions about crop health for sugarcane, ragi, and paddy, weather impacts on farming, soil nutrient management with N-P-K, pest control, and organic fertilizers.
Strictly refuse questions about politics, entertainment, general technology, or any other unrelated topic.
Use a humble, supportive, practical tone with farmer-first language. Prefer words like rainfall instead of precipitation.
Always combine traditional Indian farming wisdom with modern precision field data when both are available.
Keep every answer under 3 short sentences for fast reading on a mobile screen.
If the farmer's preferred language is Kannada, answer in simple Kannada. Otherwise answer in simple English.
""".trimIndent()

fun buildAgronomyPrompt(
    userQuestion: String,
    context: FarmAdviceContext,
): String {
    val weatherWord = when (context.weatherSignal) {
        WeatherSignal.RAIN -> "Rain"
        WeatherSignal.SUN -> "Sun"
        WeatherSignal.CLOUD -> "Cloud"
    }

    return if (isSowingQuestion(userQuestion)) {
        "The current soil moisture is ${context.soilMoisture}% and the weather prediction is $weatherWord. " +
            "The user asks: $userQuestion. Based on these agricultural parameters, give precise advice. " +
            "Keep the answer under 3 sentences for quick mobile reading."
    } else {
        "Current farm context: crop=${context.cropKey}, soil moisture=${context.soilMoisture}%, sowing index=${context.sowingIndex}%, " +
            "weather prediction=$weatherWord, weather detail=${context.weatherLabel}, latest N-P-K=${context.nitrogen}/${context.phosphorus}/${context.potassium}. " +
            "The user asks: $userQuestion. Reply like a KVK scientist with practical farmer-first advice in under 3 sentences."
    }
}

fun isSowingQuestion(userQuestion: String): Boolean {
    val query = userQuestion.lowercase()
    return listOf(
        "can i sow",
        "sow",
        "sowing",
        "seed",
        "plant now",
        "ಬಿತ್ತ",
        "ನೆಡ",
    ).any(query::contains)
}

