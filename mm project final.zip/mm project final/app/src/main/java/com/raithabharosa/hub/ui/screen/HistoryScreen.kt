package com.raithabharosa.hub.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raithabharosa.hub.R
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.local.SoilDataLog
import com.raithabharosa.hub.ui.util.formatLogTimestamp
import com.raithabharosa.hub.viewmodel.HistoryUiState
import com.raithabharosa.hub.viewmodel.HistoryViewModel

@Composable
fun HistoryRoute(
    appContainer: AppContainer,
) {
    val viewModel: HistoryViewModel = viewModel(
        factory = HistoryViewModel.factory(appContainer),
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    HistoryScreen(
        uiState = uiState,
        onDeleteLog = viewModel::deleteLog,
    )
}

@Composable
private fun HistoryScreen(
    uiState: HistoryUiState,
    onDeleteLog: (Long) -> Unit,
) {
    if (uiState.logs.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = stringResource(R.string.no_logs_yet),
                    style = MaterialTheme.typography.headlineMedium,
                )
                Text(
                    text = stringResource(R.string.history_empty_hint),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(top = 8.dp, start = 24.dp, end = 24.dp),
                )
            }
        }
    } else {
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(uiState.logs, key = { it.id }) { log ->
                HistoryCard(
                    log = log,
                    onDeleteLog = onDeleteLog,
                )
            }
        }
    }
}

@Composable
private fun HistoryCard(
    log: SoilDataLog,
    onDeleteLog: (Long) -> Unit,
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            androidx.compose.foundation.layout.Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.last_log),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        text = formatLogTimestamp(log.timestamp),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }

                IconButton(onClick = { onDeleteLog(log.id) }) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteForever,
                        contentDescription = stringResource(R.string.delete_log),
                    )
                }
            }

            Text(
                text = stringResource(R.string.moisture_template, log.moistureLevel),
                style = MaterialTheme.typography.bodyLarge,
            )
            Text(
                text = stringResource(
                    R.string.npk_template,
                    log.nitrogen,
                    log.phosphorus,
                    log.potassium,
                ),
                style = MaterialTheme.typography.bodyLarge,
            )
        }
    }
}
