package com.raithabharosa.hub.ui.util

import androidx.annotation.StringRes
import com.raithabharosa.hub.R

object CropCatalog {
    const val SUGARCANE = "sugarcane"
    const val RAGI = "ragi"
    const val PADDY = "paddy"

    val all = listOf(SUGARCANE, RAGI, PADDY)
}

@StringRes
fun cropLabelRes(cropKey: String): Int = when (cropKey) {
    CropCatalog.SUGARCANE -> R.string.crop_sugarcane
    CropCatalog.RAGI -> R.string.crop_ragi
    CropCatalog.PADDY -> R.string.crop_paddy
    else -> R.string.crop_sugarcane
}

