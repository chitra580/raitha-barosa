package com.raithabharosa.hub.data.repository

import com.raithabharosa.hub.data.model.AiAdvice
import com.raithabharosa.hub.data.model.ChatAlert
import com.raithabharosa.hub.data.model.FarmAdviceContext
import com.raithabharosa.hub.data.model.WeatherSignal
import com.raithabharosa.hub.data.prompt.isSowingQuestion

interface AgronomyAdvisorRepository {
    suspend fun requestAdvice(
        systemInstruction: String,
        contextualPrompt: String,
        userQuestion: String,
        context: FarmAdviceContext,
    ): AiAdvice
}

class LocalAgronomyAdvisorRepository : AgronomyAdvisorRepository {
    override suspend fun requestAdvice(
        systemInstruction: String,
        contextualPrompt: String,
        userQuestion: String,
        context: FarmAdviceContext,
    ): AiAdvice {
        val question = userQuestion.lowercase()
        if (!isFarmerScopeQuestion(question)) {
            return AiAdvice(
                text = if (context.languageTag == "kn") {
                    "ಕ್ಷಮಿಸಿ, ನಾನು ಬೆಳೆ, ಮಣ್ಣು, ಮಳೆ, ಕೀಟ ನಿಯಂತ್ರಣ ಮತ್ತು ಗೊಬ್ಬರದ ವಿಷಯಗಳಲ್ಲಿ ಮಾತ್ರ ಸಹಾಯ ಮಾಡುತ್ತೇನೆ."
                } else {
                    "I can only help with crop health, rainfall, soil nutrients, pest control, and fertilizers for farming."
                },
            )
        }

        return when {
            isSowingQuestion(question) -> sowingAdvice(context)
            question.contains("rain") || question.contains("weather") || question.contains("ಮಳೆ") -> rainAdvice(context)
            question.contains("fertilizer") || question.contains("dose") || question.contains("npk") ||
                question.contains("nitrogen") || question.contains("phosphorus") || question.contains("potassium") ||
                question.contains("ಗೊಬ್ಬರ") || question.contains("ಡೋಸ್") -> fertilizerAdvice(context)
            question.contains("yellow") || question.contains("pest") || question.contains("leaf") ||
                question.contains("organic") || question.contains("ಕೀಟ") || question.contains("ಎಲೆ") -> cropHealthAdvice(context)
            else -> generalAgronomyAdvice(context)
        }
    }

    private fun sowingAdvice(context: FarmAdviceContext): AiAdvice {
        val isKannada = context.languageTag == "kn"
        return when {
            context.soilMoisture > 35 || context.weatherSignal == WeatherSignal.RAIN -> AiAdvice(
                text = if (isKannada) {
                    "ಈಗಲೇ ಬಿತ್ತನೆ ಮಾಡಬೇಡಿ. ಮಣ್ಣು ಹೆಚ್ಚು ತೇವವಾಗಿದೆ ಅಥವಾ ಮಳೆಯ ಸಾಧ್ಯತೆ ಇದೆ, ಆದ್ದರಿಂದ ಬೀಜ ಹಿಡಿತ ದುರ್ಬಲವಾಗಬಹುದು. " +
                        "ಪಾರಂಪರಿಕ ಕೈಪಿಡಿ ಪರೀಕ್ಷೆಯಲ್ಲೂ ಮಣ್ಣು ಕೈಗೆ ಅಂಟಿದರೆ ಇನ್ನೂ ಸ್ವಲ್ಪ ಕಾಯಿರಿ."
                } else {
                    "Please wait before sowing. The field is too wet or rain is close, so seed placement may turn weak. " +
                        "Use the traditional hand-squeeze test too: if soil still sticks to the palm, wait a little longer."
                },
                alert = moistureAlert(context, isKannada),
            )

            context.soilMoisture < 18 -> AiAdvice(
                text = if (isKannada) {
                    "ಬಿತ್ತನೆಗೆ ಮುನ್ನ ಸ್ವಲ್ಪ ಹಗುರ ನೀರಾವರಿ ನೀಡಿ. ತೇವಾಂಶ ಕಡಿಮೆ ಇದೆ, ಆದ್ದರಿಂದ ಬೀಜ ಮೊಳಕೆ ಸಮವಾಗದಿರಬಹುದು. " +
                        "ಮೇಲ್ಮಣ್ಣು ಬೆರಳ ನಡುವೆ ಚೂರಾಗಿ ಕುಸಿಯುವ ಮಟ್ಟಕ್ಕೆ ಬಂದಾಗ ಬಿತ್ತನೆ ಪ್ರಾರಂಭಿಸಿ."
                } else {
                    "Give light irrigation before sowing. Moisture is low, so germination may be uneven right now. " +
                        "Start sowing when the topsoil breaks softly between your fingers instead of turning dusty."
                },
                alert = moistureAlert(context, isKannada),
            )

            else -> AiAdvice(
                text = if (isKannada) {
                    "ಹೌದು, ಇಂದು ಬಿತ್ತನೆಗೆ ಪರಿಸ್ಥಿತಿ ಒಳ್ಳೆಯದೆ ಕಾಣುತ್ತಿದೆ. ತೇವಾಂಶ ${context.soilMoisture}% ಮತ್ತು ಬಿತ್ತನೆ ಸೂಚ್ಯಂಕ ${context.sowingIndex}% ಇದೆ, ಆದ್ದರಿಂದ ಚೆನ್ನಾಗಿ ನೀರು ಇಳಿಯುವ ಭಾಗದಿಂದ ಆರಂಭಿಸಿ. " +
                        "ಪಾರಂಪರಿಕವಾಗಿ ಮೇಲ್ಮಣ್ಣು ಕೈಗೆ ಅಂಟದೇ ಚೂರಾಗಿದರೆ ಅದೂ ಉತ್ತಮ ಸೂಚನೆ."
                } else {
                    "Yes, the field looks ready for sowing today. Moisture is ${context.soilMoisture}% and the sowing index is ${context.sowingIndex}%, so start with the best-drained patch first. " +
                        "As a traditional check, the topsoil should crumble in your palm instead of sticking."
                },
            )
        }
    }

    private fun rainAdvice(context: FarmAdviceContext): AiAdvice {
        val isKannada = context.languageTag == "kn"
        return if (context.weatherSignal == WeatherSignal.RAIN) {
            AiAdvice(
                text = if (isKannada) {
                    "ಮಳೆಯ ಸಾಧ್ಯತೆ ಇದೆ, ಆದ್ದರಿಂದ ಹೊಸ ಗೊಬ್ಬರ ಹರಡುವುದನ್ನು ಮುಂದೂಡಿ ಮತ್ತು ನೀರು ಹರಿಯುವ ಕಾಲುವೆಗಳನ್ನು ಸ್ವಚ್ಛವಾಗಿಡಿ. " +
                        "ಬೀಜ, ಗೊಬ್ಬರ ಮತ್ತು ಜೈವಿಕ ದ್ರವ್ಯಗಳನ್ನು ಇಂದು ಒಳಗೆ ಅಥವಾ ಮುಚ್ಚಿದ ಸ್ಥಳದಲ್ಲಿ ಇರಿಸಿ."
                } else {
                    "Rain looks likely, so delay fresh fertilizer spreading and keep drainage channels open. " +
                        "Move seed, manure, and compost bags under cover today."
                },
                alert = if (isKannada) {
                    ChatAlert(
                        title = "ಮಳೆ ಎಚ್ಚರಿಕೆ",
                        summary = "ಗೊಬ್ಬರ ಹರಡುವುದು ಮತ್ತು ಹೊಸ ಬಿತ್ತನೆ ತಾತ್ಕಾಲಿಕವಾಗಿ ನಿಲ್ಲಿಸಿ.",
                    )
                } else {
                    ChatAlert(
                        title = "Rain Warning",
                        summary = "Pause fertilizer spreading and fresh sowing until the field sheds water.",
                    )
                },
            )
        } else {
            AiAdvice(
                text = if (isKannada) {
                    "ಈ ಕ್ಷಣ ಮಳೆಯ ಒತ್ತಡ ಕಡಿಮೆ ಕಾಣುತ್ತಿದೆ. ದಿನದ ಬಿಸಿಯನ್ನು ಗಮನಿಸಿ ಕೆಲಸವನ್ನು ಬೆಳಗ್ಗೆ ಅಥವಾ ಸಂಜೆ ಯೋಜಿಸಿ."
                } else {
                    "Rain pressure looks low right now. Plan field work in the cooler morning or evening hours and keep one eye on the cloud movement."
                },
            )
        }
    }

    private fun fertilizerAdvice(context: FarmAdviceContext): AiAdvice {
        val isKannada = context.languageTag == "kn"
        return when {
            context.phosphorus < 30 -> AiAdvice(
                text = if (isKannada) {
                    "ಫಾಸ್ಫರಸ್ ಮಟ್ಟ ಕಡಿಮೆಯಾಗಿದೆ, ಆದ್ದರಿಂದ ಬೇರು ಭಾಗದ ಹತ್ತಿರ ಒಡೆಯುವ ಡೋಸ್ ರೂಪದಲ್ಲಿ ಫಾಸ್ಫರಸ್ ಇರುವ ಗೊಬ್ಬರವನ್ನು ನೀಡಿ. " +
                        "ಹಸುಮಣ್ಣು ಅಥವಾ ಚೆನ್ನಾಗಿ ಕೊಳೆತ ಸಾವಯವ ಗೊಬ್ಬರದ ಜೊತೆ ಮಿಶ್ರಣ ಮಾಡಿದರೆ ಬೆಳೆ ತೆಗೆದುಕೊಳ್ಳುವಿಕೆ ಉತ್ತಮವಾಗುತ್ತದೆ."
                } else {
                    "Phosphorus is running low, so give a phosphorus-rich basal dose near the root zone rather than broadcasting it. " +
                        "Mixing it with well-rotted farmyard manure will help the crop take it up more steadily."
                },
                alert = if (isKannada) {
                    ChatAlert(
                        title = "ಕಡಿಮೆ ಫಾಸ್ಫರಸ್ ಎಚ್ಚರಿಕೆ",
                        summary = "ಫಾಸ್ಫರಸ್ ಕಡಿಮೆ ಇದೆ. ಮೂಲ ಭಾಗದ ಹತ್ತಿರ ಗೊಬ್ಬರ ಹಾಕಿ.",
                    )
                } else {
                    ChatAlert(
                        title = "Low Phosphorus Alert",
                        summary = "Phosphorus is low. Place a root-zone dose before the next irrigation.",
                    )
                },
            )

            context.nitrogen < 30 -> AiAdvice(
                text = if (isKannada) {
                    "ನೈಟ್ರೋಜನ್ ಮಟ್ಟ ಕಡಿಮೆ ಇರುವುದರಿಂದ ಸಣ್ಣ ಸಣ್ಣ ವಿಭಾಗಗಳಲ್ಲಿ ಮೇಲ್ದರ್ಜೆಯ ಡೋಸ್ ನೀಡಿ. " +
                        "ಹಗುರ ಮಳೆಯ ಮೊದಲು ಅಥವಾ ನೀರಾವರಿಯ ನಂತರ ಕೊಟ್ಟರೆ ನಷ್ಟ ಕಡಿಮೆಯಾಗುತ್ತದೆ."
                } else {
                    "Nitrogen is on the lower side, so give it in small split doses instead of one heavy application. " +
                        "A light dose just before gentle rainfall or just after irrigation will reduce loss."
                },
            )

            context.potassium < 35 -> AiAdvice(
                text = if (isKannada) {
                    "ಪೊಟ್ಯಾಸಿಯಮ್ ಸ್ವಲ್ಪ ಕಡಿಮೆ ಇದೆ, ಆದ್ದರಿಂದ ಗಿಡದ ಬಲ ಮತ್ತು ರೋಗ ತಡೆಗೆ ಪೊಟಾಶ್ ಡೋಸ್ ಯೋಚಿಸಿ. " +
                        "ಮಣ್ಣಿನ ತೇವಾಂಶ ಸರಿಯಾದಾಗ ಹಾಕಿದರೆ ಗಿಡಕ್ಕೆ ಒಳ್ಳೆಯ ಲಾಭ ಸಿಗುತ್ತದೆ."
                } else {
                    "Potassium looks a bit low, so plan a potash dose to support stem strength and stress tolerance. " +
                        "Apply it when the soil is moist enough for the root zone to absorb it well."
                },
            )

            else -> AiAdvice(
                text = if (isKannada) {
                    "ಪ್ರಸ್ತುತ N-P-K ಸಮತೋಲನ ಸರಾಸರಿ ಮಟ್ಟದಲ್ಲಿದೆ. ದೊಡ್ಡ ಒಮ್ಮೆ ಡೋಸ್ ಕೊಡಬೇಡಿ; ಬೆಳೆಯ ಹಂತಕ್ಕೆ ತಕ್ಕಂತೆ ವಿಭಜಿತ ಡೋಸ್ ಉತ್ತಮ."
                } else {
                    "Your current N-P-K balance looks fairly steady. Avoid one heavy dose; split the fertilizer by crop stage for safer uptake."
                },
            )
        }
    }

    private fun cropHealthAdvice(context: FarmAdviceContext): AiAdvice {
        val isKannada = context.languageTag == "kn"
        val phosphorusLine = if (context.phosphorus < 30) {
            if (isKannada) {
                "ಫಾಸ್ಫರಸ್ ಕಡಿಮೆ ಇರುವುದೂ ಬೆಳೆಯ ಬಣ್ಣ ಮತ್ತು ಬೇರು ಬೆಳವಣಿಗೆಗೆ ಪರಿಣಾಮ ಬೀರುವ ಸಾಧ್ಯತೆ ಇದೆ."
            } else {
                "Low phosphorus may also be weakening color and root growth."
            }
        } else {
            ""
        }

        return AiAdvice(
            text = if (isKannada) {
                "ಮೊದಲು ಹಾನಿಗೊಂಡ ಎಲೆಗಳನ್ನು ಹತ್ತಿರದಿಂದ ನೋಡಿ ಕೀಟದ ಗುರುತು ಅಥವಾ ಬಣ್ಣ ಬದಲಾವಣೆಯನ್ನು ಪರಿಶೀಲಿಸಿ. " +
                    "ನೀಮ್ ಆಧಾರಿತ ಸಿಂಪಡಣೆ ಮತ್ತು ಚೆನ್ನಾಗಿ ಕೊಳೆತ ಸಾವಯವ ಗೊಬ್ಬರವನ್ನು ಪ್ರಾಥಮಿಕ ಸುರಕ್ಷಿತ ಕ್ರಮವಾಗಿ ಬಳಸಬಹುದು. $phosphorusLine".trim()
            } else {
                "First inspect the damaged leaf closely for pest marks or uneven yellowing. " +
                    "A neem-based spray and well-rotted organic manure are safe first steps while you monitor the patch. $phosphorusLine".trim()
            },
            alert = if (context.phosphorus < 30) {
                if (isKannada) {
                    ChatAlert(
                        title = "ಪೋಷಕಾಂಶ ಎಚ್ಚರಿಕೆ",
                        summary = "ಕಡಿಮೆ ಫಾಸ್ಫರಸ್ ಬೆಳೆ ಬೆಳವಣಿಗೆಯನ್ನು ತಡೆಯಬಹುದು.",
                    )
                } else {
                    ChatAlert(
                        title = "Nutrient Alert",
                        summary = "Low phosphorus may be contributing to weak crop growth.",
                    )
                }
            } else {
                null
            },
        )
    }

    private fun generalAgronomyAdvice(context: FarmAdviceContext): AiAdvice {
        val isKannada = context.languageTag == "kn"
        return AiAdvice(
            text = if (isKannada) {
                "ನಿಮ್ಮ ಪ್ರಶ್ನೆಯನ್ನು ಬೆಳೆ, ಮಣ್ಣು, ಮಳೆ ಅಥವಾ ಗೊಬ್ಬರದ ದೃಷ್ಟಿಯಿಂದ ನೋಡಿದರೆ ಈಗ ತೇವಾಂಶ ${context.soilMoisture}% ಮತ್ತು ಬಿತ್ತನೆ ಸೂಚ್ಯಂಕ ${context.sowingIndex}% ಇದೆ. " +
                    "ಒಂದೇ ಸಲ ದೊಡ್ಡ ನಿರ್ಧಾರ ತೆಗೆದುಕೊಳ್ಳದೆ ಸಣ್ಣ ಭಾಗದಲ್ಲಿ ಪರೀಕ್ಷಿಸಿ ನಂತರ ಉಳಿದ ಹೊಲಕ್ಕೆ ಮುಂದುವರಿಯುವುದು ಸುರಕ್ಷಿತ."
            } else {
                "Looking at your field conditions, soil moisture is ${context.soilMoisture}% and the sowing index is ${context.sowingIndex}%. " +
                    "It is safer to test one small patch first and then extend the same step across the rest of the field."
            },
        )
    }

    private fun moistureAlert(
        context: FarmAdviceContext,
        isKannada: Boolean,
    ): ChatAlert = if (context.soilMoisture > 35) {
        if (isKannada) {
            ChatAlert(
                title = "ಹೆಚ್ಚಿನ ತೇವಾಂಶ ಎಚ್ಚರಿಕೆ",
                summary = "ಮಣ್ಣು ತುಂಬಾ ತೇವವಾಗಿದೆ. ನೀರು ಇಳಿದ ಬಳಿಕ ಮಾತ್ರ ಬಿತ್ತನೆ ಮಾಡಿ.",
            )
        } else {
            ChatAlert(
                title = "High Moisture Alert",
                summary = "The field is too wet. Let the water drain before sowing.",
            )
        }
    } else {
        if (isKannada) {
            ChatAlert(
                title = "ಕಡಿಮೆ ತೇವಾಂಶ ಎಚ್ಚರಿಕೆ",
                summary = "ಹಗುರ ನೀರಾವರಿ ನೀಡಿ ನಂತರ ಮತ್ತೆ ತೇವಾಂಶ ಪರಿಶೀಲಿಸಿ.",
            )
        } else {
            ChatAlert(
                title = "Low Moisture Alert",
                summary = "Give light irrigation and recheck the field before sowing.",
            )
        }
    }

    private fun isFarmerScopeQuestion(question: String): Boolean = listOf(
        "sow",
        "seed",
        "crop",
        "leaf",
        "weather",
        "rain",
        "soil",
        "moisture",
        "nitrogen",
        "phosphorus",
        "potassium",
        "fertilizer",
        "organic",
        "pest",
        "sugarcane",
        "ragi",
        "paddy",
        "can i sow",
        "ಮಳೆ",
        "ಮಣ್ಣು",
        "ಕೀಟ",
        "ಬೆಳೆ",
        "ಗೊಬ್ಬರ",
        "ತೇವಾಂಶ",
        "ನೈಟ್ರೋಜನ್",
        "ಫಾಸ್ಫರಸ್",
        "ಪೊಟ್ಯಾಸಿಯಮ್",
        "ಕಬ್ಬು",
        "ರಾಗಿ",
        "ನೆಲ್ಲಿ",
    ).any(question::contains)
}

