package com.raithabharosa.hub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.raithabharosa.hub.ui.RaithaApp
import com.raithabharosa.hub.ui.theme.RaithaBharosaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val container = (application as RaithaBharosaApplication).container

        setContent {
            RaithaBharosaTheme {
                RaithaApp(appContainer = container)
            }
        }
    }
}

