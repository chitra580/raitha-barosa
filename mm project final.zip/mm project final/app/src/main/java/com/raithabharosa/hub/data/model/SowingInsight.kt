package com.raithabharosa.hub.data.model

data class SowingInsight(
    val score: Int,
    val tone: InsightTone,
    val statusMessage: String,
    val quickAction: String,
)

enum class InsightTone {
    OPTIMAL,
    CAUTION,
    STOP,
}

