package com.raithabharosa.hub.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.raithabharosa.hub.data.AppContainer
import com.raithabharosa.hub.data.model.InsightTone
import com.raithabharosa.hub.data.model.KrishiPlanItem
import com.raithabharosa.hub.data.repository.FarmerRepository
import com.raithabharosa.hub.ui.util.CropCatalog
import java.time.LocalDate
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class ActionPlanUiState(
    val primaryCrop: String = CropCatalog.SUGARCANE,
    val items: List<KrishiPlanItem> = emptyList(),
)

class ActionPlanViewModel(
    farmerRepository: FarmerRepository,
) : ViewModel() {
    val uiState: StateFlow<ActionPlanUiState> = farmerRepository.profile
        .map { profile ->
            val crop = profile?.primaryCrop ?: CropCatalog.SUGARCANE
            ActionPlanUiState(
                primaryCrop = crop,
                items = buildPlan(crop),
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ActionPlanUiState(
                items = buildPlan(CropCatalog.SUGARCANE),
            ),
        )

    companion object {
        fun factory(appContainer: AppContainer) = viewModelFactory {
            initializer {
                ActionPlanViewModel(appContainer.farmerRepository)
            }
        }
    }
}

private fun buildPlan(crop: String): List<KrishiPlanItem> {
    val today = LocalDate.now()
    val forecast = listOf(
        "Sunny",
        "Cloudy",
        "Storm",
        "Light rain",
        "Partly cloudy",
        "Sunny",
        "Cloudy",
    )

    return forecast.mapIndexed { index, condition ->
        val date = today.plusDays(index.toLong())
        when (index) {
            0 -> KrishiPlanItem(
                date = date,
                condition = condition,
                recommendedActivity = "Finish fertilization across the prepared rows.",
                riskLevel = InsightTone.CAUTION,
                warningMessage = "Storm expected soon. Finish fertilization now.",
            )

            1 -> KrishiPlanItem(
                date = date,
                condition = condition,
                recommendedActivity = "Pause fresh sowing and cover seed stock.",
                riskLevel = InsightTone.CAUTION,
                warningMessage = "Storm is likely tomorrow. Delay sowing.",
            )

            2 -> KrishiPlanItem(
                date = date,
                condition = condition,
                recommendedActivity = "Stop field application and protect inputs from runoff.",
                riskLevel = InsightTone.STOP,
                warningMessage = "Storm day: avoid sowing and fertilizer application.",
            )

            else -> KrishiPlanItem(
                date = date,
                condition = condition,
                recommendedActivity = regularActivity(crop = crop, condition = condition),
                riskLevel = if (condition.contains("rain", ignoreCase = true)) {
                    InsightTone.CAUTION
                } else {
                    InsightTone.OPTIMAL
                },
            )
        }
    }
}

private fun regularActivity(
    crop: String,
    condition: String,
): String = when (crop) {
    CropCatalog.RAGI -> when {
        condition.contains("rain", ignoreCase = true) -> "Weed lightly and keep drainage channels open."
        else -> "Complete line sowing and maintain a fine tilth."
    }

    CropCatalog.PADDY -> when {
        condition.contains("rain", ignoreCase = true) -> "Monitor bund strength and protect nursery beds."
        else -> "Prepare puddling schedule and check nursery moisture."
    }

    else -> when {
        condition.contains("rain", ignoreCase = true) -> "Inspect furrows and avoid extra irrigation."
        else -> "Continue ridge preparation and plan the next irrigation turn."
    }
}

