package com.raithabharosa.hub.data.repository

import com.raithabharosa.hub.data.local.SoilDataLogDao
import com.raithabharosa.hub.data.model.SoilStatus
import com.raithabharosa.hub.data.model.toEntity
import com.raithabharosa.hub.data.simulation.DataGenerator
import kotlinx.coroutines.flow.Flow

class SoilRepository(
    private val soilDataLogDao: SoilDataLogDao,
    private val dataGenerator: DataGenerator,
) {
    val logs = soilDataLogDao.observeAllLogs()
    val latestLog = soilDataLogDao.observeLatestLog()

    fun generateCurrentStatus(): SoilStatus = dataGenerator.generateCurrentStatus()

    suspend fun saveLog(status: SoilStatus) {
        soilDataLogDao.insert(status.toEntity())
    }

    suspend fun saveManualLog(
        moistureLevel: Int,
        nitrogen: Int,
        phosphorus: Int,
        potassium: Int,
    ) {
        saveLog(
            SoilStatus(
                moistureLevel = moistureLevel,
                nitrogen = nitrogen,
                phosphorus = phosphorus,
                potassium = potassium,
            ),
        )
    }

    suspend fun deleteLog(id: Long) {
        soilDataLogDao.deleteById(id)
    }
}

